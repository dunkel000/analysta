# analysta

[![PyPI - Version](https://img.shields.io/pypi/v/analysta.svg)](https://pypi.org/project/analysta)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/analysta.svg)](https://pypi.org/project/analysta)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install analysta
```

## License

`analysta` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
