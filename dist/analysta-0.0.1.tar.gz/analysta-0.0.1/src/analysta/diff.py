def hello(): print("Hello, Analysta!")
